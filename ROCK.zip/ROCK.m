% constants
ult = 4;
gyro = 2;
touch = 1;
right = 'C';
left = 'B';
brick.GyroCalibrate(gyro);

% color = 3;

setGlobalDirection(1);

while true
    %moveUntilTouch(brick, ult, gyro, left, right, touch);
    moveUntil(brick, gyro, left, right, (-8/(2*pi)*360));
    %turn(brick, gyro, left, right, (90 * getGlobalDirection()));
    break;
end

function setGlobalDirection(val)
    global direction;
    direction = val;
end

function r = getGlobalDirection()
    global direction;
    r = direction;
end

function turn(brick, gyro, left, right, dir)
    cur = brick.GyroAngle(gyro);

    if isnan(cur)
        cur = 0;
    end

    tar = cur + dir - mod(cur, 90);

    Kp = 0.53;
    Ki = 0.075;
    Kd = 0.1;
    err = tar - cur;

    disp(err);
    disp(cur);

    prevIntegral = 0;
    prevErr = err;
    intActZone = 10;

    while abs(err) > 4
        prop = Kp * err;

        derivative = Kd * (err - prevErr);

        if abs(err) < intActZone
            integral = Ki * (err + prevIntegral);
        else
            integral = 0;
        end

        factor = prop + integral + derivative;

        moveLeft(factor, brick, left);
        moveRight(-factor, brick, right);

        cur = brick.GyroAngle(gyro);
        prevIntegral = prevIntegral + err;
        prevErr = err;
        err = tar - cur;

        if brick.TouchPressed(1)
            setGlobalRunning(false);
        end
    end

    moveRight(0, brick, right);
    moveLeft(0, brick, left);

    disp('done');
end

function moveLeft(speed, brick, left)
    brick.MoveMotor(left, speed);
end

function [angle] = getLeft(brick, left)
    angle = brick.GetMotorAngle(left);
end

function moveRight(speed, brick, right)
    brick.MoveMotor(right, speed);
end

function [angle] = getRight(brick, right)
    angle = brick.GetMotorAngle(right);
end

function moveForward(speed, brick, left, right, offset)
    moveLeft((speed * offset), brick, left);
    moveRight((speed/offset), brick, right);
end

function moveUntilTouch(brick, ult, gyro, left, right, touch)
    Kp = 1;
    Ki = 0;
    Kd = 0;

    ang = brick.GyroAngle(gyro);
    curAng = brick.GyroAngle(gyro);

    if isnan(curAng)
       curAng = 0;
    end
    
    if isnan(ang)
        ang = 0;
    end

    err = curAng - ang;

    while brick.UltrasonicDist(ult) < 50 && ~brick.TouchPressed(touch)
        off = err * Kp;

        moveForward(factor, brick, left, right, off);

        curAng = brick.GyroAngle(gyro);
        err = curAng - ang;

        disp(brick.UltrasonicDist(ult));
        disp(ang);
        disp(curAng);
    end

    if (brick.UltrasonicDist(ult) > 50)
        setGlobalDirection(-1);
    else
        setGlobalDirection(1);
    end

    brick.StopAllMotors();

    brick.MoveMotorAngleRel(left, 50, -3.5 * 360, 'Brake');
    brick.MoveMotorAngleRel(right, 50, -3.5 * 360, 'Brake');
    
    disp('done');
end

function moveUntil(brick, gyro, left, right, dist)
    Kp = 2;

    brick.ResetMotorAngle(left);
    brick.ResetMotorAngle(right);

    cur = 0;
    tar = dist;
    err = tar - cur;

    Kp2 = 1;

    ang = brick.GyroAngle(gyro);
    
    if isnan(ang)
        ang = 0;
    end

    curAng = ang;

    while abs(err) > 5
        prop = Kp * err;

        factor = prop;

        off = (curAng - ang) * Kp2;

        disp(factor);
        disp(off);
        disp(cur);
        disp(err);

        moveForward(factor, brick, left, right, off);

        cur = (getLeft(brick, left) + getRight(brick, right))/2;
        err = tar - cur;

        curAng = brick.GyroAngle(gyro);
        if(isnan(curAng))
            curAng = 0;
        end


        disp(ang);
        disp(curAng);
    end

    brick.StopAllMotors();
    disp('done');
end